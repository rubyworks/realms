
t = Time.now

require 'roll/library'

puts "Load Time: #{Time.now - t} seconds"

