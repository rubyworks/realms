# require 'roll/library'
# 
# p Library.list
# 
# tl = Library.open('temp')
# 
# p tl
# 
# tl.require('dir1/gemorder/temp')
# 
